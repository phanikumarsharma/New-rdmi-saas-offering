﻿param
(

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $SubscriptionId,

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $RGName,

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $UserName,

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $Password
)

try
{
    Write-Output "Login Into Azure RM.."
    
    $Passwd = $Password | ConvertTo-SecureString -asPlainText -Force
    $Credential = New-Object System.Management.Automation.PSCredential($UserName,$Passwd)
    Login-AzureRmAccount -Credential $Credential

    Write-Output "Selecting Azure Subscription.."
    Select-AzureRmSubscription -SubscriptionId $SubscriptionId
    Write-Output "Checking if the resource group $RGName exists";
    $RG = Get-AzureRmResourceGroup -Name $RGName -ErrorAction SilentlyContinue
    if ($RG)
    {
        Write-Output "Deleting the resource group $RGName ...";
        Remove-AzureRmResourceGroup -Name $RGName -Force -ErrorAction Stop 
        Write-Output "Resource group with name $RGName has been deleted"
    }
}
catch [Exception]
{
    Write-Output $_.Exception.Message
}